<?php 

require 'vendor/autoload.php';
use GuzzleHttp\Client;


$client = new Client([
	'headers' => [ 'content-type' => 'application/json', 'Accept' => 'application/json'],
	]);

		$response = $client->request('GET', 'https://coronavirus-ph-api.herokuapp.com/cases', [
		// $response = $client->request('GET', 'https://coronavirus-ph-api.now.sh/cases', [

		'json'	=> [
			'code'	=> 'IwAR2ZpsKDUgqc92DeeWmOdRCxicAH3LY6dlgiUJyZLc9cdWjim9fJdr9bgg8',
		],
	]);

	$data = $response->getBody();
 
	$data = json_decode($data);

 


	require 'views/index.php';
