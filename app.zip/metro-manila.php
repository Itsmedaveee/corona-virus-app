
<?php 

require 'vendor/autoload.php';

use GuzzleHttp\Client;
 

	$client = new Client([
	'headers' => [ 'content-type' => 'application/json', 'Accept' => 'application/json'],
	]);

	$response = $client->request('GET', 'https://coronavirus-ph-api.now.sh/mm-checkpoints', [
		'json'	=> [
			'code'	=> 'IwAR3tZdK1vyhSl8JAFiZi5YfCiGNCJeATz_Y-WKddio2ABgQJmgpUCw7IEAo',
		],
	]);

	$data = $response->getBody();
 
	$data = json_decode($data);


	require 'views/manila.php';
	

 
 



