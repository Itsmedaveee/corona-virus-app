 <!DOCTYPE html>
<html lang="en">

<!-- Mirrored from seantheme.com/color-admin/admin/html/page_blank.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jan 2020 06:25:46 GMT -->
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    

    <link href="public/css/app.min.css" rel="stylesheet" />
    <link href="public/css/red.min.css" rel="stylesheet" />
    <link href="public/css/bootstrap-select.min.css" rel="stylesheet" />

    <!-- ================== END BASE CSS STYLE ================== -->
</head>
<body>
 <!-- begin #page-loader -->
    <div id="page-loader" class="fade show">
        <span class=""></span>
    </div>
    <!-- end #page-loader -->
 <!-- begin #page-container -->
        <div id="page-container" class="fade page-sidebar-fixed page-header-fixed">

	<!-- begin #page-container -->
	<div id="page-container" >
		<!-- begin #header -->
		<div id="header" class="header navbar-inverse">
			<!-- begin navbar-header -->
			<div class="navbar-header">
				<a href="#" class="navbar-brand"><span></span>  Corona Virus Tracking System Developed By Dave Del Rosario</b> &nbsp;</a>
				<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			 
				 
					</div>
				</li>
			</ul>
			<!-- end header-nav -->
		</div>
 
 </div>

 
 <br>

 <br>
 <br>
 <br>


 <div class="col-md-12">
	 <div class="form-group">
	 	<a href="country.php" class="btn btn-primary">All Country</a>
	 	<a href="index.php" class="btn btn-primary">Tracking Philippines (NCOV-19)</a>
	 </div>
 </div>
<div class="col-md-12">
<div class="panel panel-inverse">
	<div class="panel-heading">
		<h4 class="panel-title">STATS</h4>
		<div class="panel-heading-btn">
			
		</div>
	</div>
	<div class="panel-body">

		<h1 class="page-header">	</h1>

            <div class="row">
           	<?php foreach ($data as $country) : ?>
 			 <div class="col-xl-3 col-md-6">
                    <div class="widget widget-stats bg-inverse">
                        <div class="stats-icon">
                            <div class="icon-img">
                                <img src="{{ asset('img/app.png') }}" alt="" />
                            </div>
                        </div>
                        <div class="stats-info">
							<th><img src="<?= $country->countryInfo->flag; ?>"></th>
							<br>
							<br>
							<th>Country : <b><?= $country->country;?> </b></th>
							<br>
							<th>Cases : <b><?= $country->cases;?></b></th>
							<br>
							<th>Today Cases : <b><?= $country->todayCases;?></b></th>
							<br>
							<th>Deaths : <b><?= $country->deaths;?></b> </th>
							<br>
							<th>Today Deaths : <b><?= $country->todayDeaths;?></b></th>
							<br>
							<th>Recovered : <b><?= $country->recovered;?></b></th>
							<br>
							<th>Actived : <b><?= $country->active;?></b></th>
							<br>
							<th>Critical : <b><?= $country->critical;?></b></th>
							<br>
							<th>Cases Per One Million : <b><?= $country->casesPerOneMillion;?></b></th>
							<br>
							<th>Death Per One Million : <b><?= $country->deathsPerOneMillion;?></b></th>  

                        </div>
                        <div class="stats-link">
                            <a href="javascript:;"></a>
                        </div>
                    </div>
                </div>
                <!-- end col-3 -->
                <!-- begin col-3 -->
               <?php endforeach ;?>
            </div>
        </div>
    </div>
    </div>
 

<div class="col-md-12">
<div class="panel panel-inverse">
	<div class="panel-heading">
		<h4 class="panel-title">Cases Lists</h4>
		<div class="panel-heading-btn">
		 
		</div>
	</div>

	<div class="table-responsive">
	<div class="panel-body">



	 <table id="example" class="table table-bordered">
	 	<thead>
	 		<tr>
	 			<th>Country</th>
	 			<th>Cases</th>
	 			<th>Today Cases</th>
	 			<th>Deaths</th>
	 			<th>Today Deaths</th>
	 			<th>Recovered</th>
	 			<th>Actived</th>
	 			<th>Critical</th>
	 			<th>Cases Per One Million</th>
	 			<th>Death Per One Million</th>
	 		</tr>
	 	</thead>
	 	<tbody>
		 	<?php foreach ($data as $country) : ?>

		 		<tr>
		 			<td><?= $country->country;?> </td>
		 			<td><?= $country->cases;?> </td>
		 			<td><?= $country->todayCases;?> </td>
		 			<td><?= $country->deaths;?> </td>
		 			<td><?= $country->todayDeaths;?> </td>
		 			<td><?= $country->recovered;?> </td>
		 			<td><?= $country->active;?> </td>
		 			<td><?= $country->critical;?> </td>
		 			<td><?= $country->casesPerOneMillion;?> </td>
		 			<td><?= $country->deathsPerOneMillion;?> </td>
		 		</tr>
		 	<?php endforeach ;?>
	 	</tbody>
	 </table>


    <script src="public/js/app.min.js"></script>
    <script src="public/js/theme/default.min.js"></script>
</body>
</html>