 <!DOCTYPE html>
<html lang="en">

<!-- Mirrored from seantheme.com/color-admin/admin/html/page_blank.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jan 2020 06:25:46 GMT -->
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    

    <link href="public/css/app.min.css" rel="stylesheet" />
    <link href="public/css/red.min.css" rel="stylesheet" />
    <link href="public/css/bootstrap-select.min.css" rel="stylesheet" />

    <!-- ================== END BASE CSS STYLE ================== -->
</head>
<body>
 <!-- begin #page-loader -->
    <div id="page-loader" class="fade show">
        <span class=""></span>
    </div>
    <!-- end #page-loader -->
 <!-- begin #page-container -->
        <div id="page-container" class="fade page-sidebar-fixed page-header-fixed">

	<!-- begin #page-container -->
	<div id="page-container" >
		<!-- begin #header -->
		<div id="header" class="header navbar-inverse">
			<!-- begin navbar-header -->
			<div class="navbar-header">
				<a href="#" class="navbar-brand"><span></span>  Corona Virus Tracking System Developed By Dave Del Rosario</b> &nbsp;</a>
				<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			 
				 
					</div>
				</li>
			</ul>
			<!-- end header-nav -->
		</div>
 
 </div>

 
 <br>

 <br>
 <br>
 <br>

<!--  <div class="col-md-12">
	 <div class="form-group">
	 	<a href="metro-manila.php" class="btn btn-primary">Tracking Manila Checkpoint</a>
	 </div>
 </div>
  -->
<div class="col-md-12">
<div class="panel panel-inverse">
	<div class="panel-heading">
		<h4 class="panel-title">STATS</h4>
		<div class="panel-heading-btn">
		 
		</div>
	</div>
	<div class="panel-body">

		<h1 class="page-header">	
<!-- begin col-3 -->
<div class="col-xl-3 col-md-6">
<div class="widget widget-stats bg-danger">
<div class="stats-icon">
<div class="icon-img">
</div>
</div>
<div class="stats-info">
<h4>TOTAL CASES</h4>
<p><?php echo  count($data);?></h1></p>    
</div>
<div class="stats-link">
</div>
</div>
</div>
 
<div class="col-md-12">
<div class="panel panel-inverse">
	<div class="panel-heading">
		<h4 class="panel-title">Cases Lists</h4>
		<div class="panel-heading-btn">
		 
		</div>
	</div>

	<div class="table-responsive">
	<div class="panel-body">



	 <table id="example" class="table table-bordered">
	 	<thead>
	 		<tr>
	 			<th>Cases Territory Place</th>
	 			<th>Confirmed</th>
	 			<th>Recovered</th>
	 			<th>Died</th>
	 	 
	 		</tr>
	 	</thead>
	 	<tbody>
		 	<?php foreach ($data as $cases) : ?>

		 		<tr>
		 			<td><?= $cases->country_territory_place ;?> </td>
		 			<td><?= $cases->confirmed ;?> </td>
		 			<td><?= $cases->recovered ;?> </td>
		 			<td><?= $cases->died ;?> </td>
		 		</tr>
		 	<?php endforeach;?>
	 	</tbody>
	 </table>


    <script src="public/js/app.min.js"></script>
    <script src="public/js/theme/default.min.js"></script>
</body>
</html>