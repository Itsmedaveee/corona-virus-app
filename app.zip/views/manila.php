 <!DOCTYPE html>
<html lang="en">

<!-- Mirrored from seantheme.com/color-admin/admin/html/page_blank.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jan 2020 06:25:46 GMT -->
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    
    <!-- ================== BEGIN BASE CSS STYLE ================== -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

    <link href="public/css/app.min.css" rel="stylesheet" />
    <link href="public/css/toastr.css" rel="stylesheet" />
    <link href="public/css/font-awesome.min.css" rel="stylesheet" />
    <link href="public/css/ionicons.min.css" rel="stylesheet" />
    <link href="public/css/red.min.css" rel="stylesheet" />
    <link href="public/css/bootstrap-select.min.css" rel="stylesheet" />
	<link href="public/css/select2.min.css" rel="stylesheet" />

	<link href="public/css/nv.d3.css" rel="stylesheet" />  
	<script src="public/css/sweetalert2/sweetalert2.min.js"></script>
	<link href="public/css/sweetalert2/sweetalert2.min.css" rel="stylesheet">

	<link href="public/assets/plugins/datatable/DataTables-1.10.18/css/dataTables.bootstrap.min.css" rel="stylesheet" >

    <!-- ================== END BASE CSS STYLE ================== -->
</head>
<body>
   <!-- begin #page-loader -->
    <div id="page" class="fade show">
        <span class=""></span>
    </div>
    <!-- end #page-loader -->
 <!-- begin #page-container -->
        <div id="page-container" class="fade page-sidebar-fixed page-header-fixed">

	<!-- begin #page-container -->
	<!-- begin #page-container -->
		<div id="page-container" >
			<!-- begin #header -->
			<div id="header" class="header navbar-inverse" style="background: #117A65">
				<!-- begin navbar-header -->
				<div class="navbar-header">
					<a href="index.html" class="navbar-brand"><span></span>  &nbsp; <b>NTC</b> &nbsp;Assessment System</a>
					 
				</div>
			 
			</div>
		</div>
</div>
	 
 <br>

 <br>
 <br>
 <br>

 <div class="col-md-12">
	 <div class="form-group">
	 	<a href="index.php" class="btn btn-primary">Corona-Virus Tracking</a>
	 </div>
 </div>
 
<div class="col-md-12">
<div class="panel panel-inverse">
	<div class="panel-heading">
		<h4 class="panel-title">STATS</h4>
		<div class="panel-heading-btn">
		 
		</div>
	</div>
	<div class="panel-body">

		<h1 class="page-header">	
<!-- begin col-3 -->
<div class="col-xl-3 col-md-6">
<div class="widget widget-stats bg-primary">
<div class="stats-icon">
<div class="icon-img">
</div>
</div>
<div class="stats-info">
<h4>TOTAL CASES</h4>
<p><?php echo  count($data);?></h1></p>    
</div>
<div class="stats-link">
</div>
</div>
</div>
 
<div class="col-md-12">
<div class="panel panel-inverse">
	<div class="panel-heading">
		<h4 class="panel-title">Cases Lists</h4>
		<div class="panel-heading-btn">
		 
		</div>
	</div>

	<div class="table-responsive">
	<div class="panel-body">



	 <table id="example" class="table table-bordered">
	 	<thead>
	 		<tr>
	 			<th>ID</th>
	 			<th>District</th>
	 			<th>City</th>
	 			<th>Location</th>
	 			<th>Type</th>
	 			<th>Lat</th>
	 			<th>Long</th>
	 			<th>Description</th>
	 		 
	 		</tr>
	 	</thead>
	 	<tbody>
		 	<?php foreach ($data as $manila) : ?>
		 		<tr>
		 			<td><?= $manila->id; ?></td>
		 			<td><?= $manila->district; ?></td>
		 			<td><?= $manila->city; ?></td>
		 			<td><?= $manila->location; ?></td>
		 			<td><?= $manila->type; ?></td>
		 			<td><?= $manila->lat; ?></td>
		 			<td><?= $manila->lng; ?></td>
		 			<td><?= $manila->description; ?></td>
		 			
		 	<?php endforeach ;?>
	 	</tbody>
	 </table>


</body>
</html>