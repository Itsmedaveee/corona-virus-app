<?php 

require 'vendor/autoload.php';
use GuzzleHttp\Client;


$client = new Client([
	'headers' => [ 'content-type' => 'application/json', 'Accept' => 'application/json'],
	]);

		$response = $client->request('GET', 'https://corona.lmao.ninja/countries', [
		'json'	=> [
			'code'	=> 'IwAR0g_PvDKiIZGSOevdYozOmBf-mc7_eQPzzAyoXJ81PdvzlCmWw9vNoMjVU',
		],
	]);

	$data = $response->getBody();
 
	$data = json_decode($data);



 	require 'views/country.php';
